package func;
import util.Matrix;
import util.Vector;

public class QuadraForm implements RealFunc {

	public Matrix Q;
	
	public QuadraForm(Matrix Q) {
		this.Q=new Matrix(Q);
	}
	
	@Override
	public double eval(Vector x) {
		
		/* TODO */
		return x.scalar((this.Q.mult(x.leftmul(0.5))));
	}

	@Override
	public Vector grad(Vector x) {
		
		/* TODO */
		
		return this.Q.mult(x);
	}
	
	@Override
	public int dim() {
		return Q.nb_cols();
	}

}
