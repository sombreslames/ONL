package func;

import util.Vector;

public class Rosenbrock implements RealFunc {


	public double eval(Vector v) {
		
		/* TODO */
		
		return 0;
	}

	
	public Vector grad(Vector v) {
		
		/* TODO */
		
		return null;
	}
	
	@Override
	public int dim() {
		return 2;
	}

	
}
