package solve;
import line.Dichotomy;
import line.LineSearch;
import func.RealFunc;
import util.Vector;

/**
 * Non-linear variant of the conjugate gradients.
 * 
 * @author Gilles Chabert
 *
 */
public class ConjugateGradients extends Algorithm {

	/**
	 * Build the algorithm for a given function and
	 * with an underlying line search technique.
	 * 
	 * @param f the function
	 * @param s the line search algorithm
	 */
	/**
	 * First direction of the current search (given by "start")
	 */
	protected Vector d;
	/**
	 * The function to minimize.
	 */
	protected RealFunc f;
	/**
	 * Point of the intipos search (given by "start")
	 */
	protected Vector x0;
	protected LineSearch s;
	
	public ConjugateGradients(RealFunc f, LineSearch s) {
		this.f = f;
		this.s = s;
		/* TODO */
	
	}
	
	/**
	 * Start the iteration
	 */
	public void start(Vector x0) {
		this.x0 = x0;
		this.d  = this.f.grad(x0).minus();
		super.start(x0);

		/* TODO */
		
	}
	
	/**
	 * Calculate the next iterate.
	 * 
	 * (update iter_vec).
	 */
	public void compute_next() throws EndOfIteration {

		/* TODO */
		
		/* Calcul de la nouvell direction */
		Vector gk1 = this.f.grad(this.d).minus();
		this.d = gk1.add(this.d.leftmul(Math.pow(gk1.norm(),2)/Math.pow(this.d.norm(), 2)));
		/* calcul de la nouvelle pos*/
		double alpha = -(this.f.grad(this.iter_vec).scalar(this.d)/this.d.scalar(this.d));
		iter_vec=this.iter_vec.add(this.d.leftmul(alpha));
	}
}
